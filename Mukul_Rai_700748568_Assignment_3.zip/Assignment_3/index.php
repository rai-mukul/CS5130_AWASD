<?php
// Redirect to register.php
header("Location: register.php");
exit; // Make sure to exit after the redirect to prevent further execution
?>